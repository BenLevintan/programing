# Matrix Mask Picker
A simple python tool for toggling matrix masks on and off in python.

Welcome to the Matrix Mask Picker application! This branch, named "Matrix visualizer 1.0.0," is focused on refining and enhancing the existing codebase to make it more modular, professional, and collaborative.
