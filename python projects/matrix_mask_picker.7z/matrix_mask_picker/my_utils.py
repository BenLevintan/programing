#!/usr/bin/python3

import json
import csv
import sys
import numpy as np

from PyQt5 import QtWidgets, QtGui
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QTableWidget,
    QTableWidgetItem, QFileDialog, QMessageBox
)

class table_create:
    def __init__(self, table, rows, columns, x_pos, y_pos):
        table.setGeometry(x_pos, y_pos, columns * 41, rows * 33)
        table.setRowCount(rows)
        table.setColumnCount(columns)
        for i in range(columns):
            table.setColumnWidth(i, 5)